@echo off
cd /d "%~dp0"
title FBH Materialplaner - Menue-Layout Synchronisation

echo =======================================================================
echo   FBH Materialplaner - Menue-Layout Synchronisation
echo =======================================================================
echo.

if not exist "%~dp0menu_layout.json" goto :nofile

echo [Info] Lese menu_layout.json und aktualisiere default_toolbar_layout.js...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Apply_Menu_Layout.ps1"

if %ERRORLEVEL% EQU 0 (
    echo =======================================================================
    echo [Erfolg] Das Menue-Layout wurde erfolgreich uebertragen!
    echo.
    echo Die Datei default_toolbar_layout.js wurde aktualisiert.
    echo Alle Browser laden nun beim Starten exakt diese Menue-Anordnung!
    echo =======================================================================
    goto :end
) else (
    echo [Fehler] Beim Aktualisieren des App-Codes ist ein Fehler aufgetreten.
    goto :end
)

:nofile
echo [Fehler] Die Datei menu_layout.json wurde nicht gefunden!
echo Bitte speichern Sie zuerst in der App das Menue-Layout.

:end
echo.
