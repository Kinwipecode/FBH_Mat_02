# FBH Materialplaner - PowerShell Layout Synchronisation Skript
$scriptPath = $PSScriptRoot
$jsonPath = Join-Path $scriptPath "menu_layout.json"
$targetJsPath = Join-Path $scriptPath "default_toolbar_layout.js"

if (Test-Path $jsonPath) {
    $rawJson = Get-Content -Raw -Path $jsonPath -Encoding UTF8
    $jsonObj = $rawJson | ConvertFrom-Json
    
    # Ensure updatedAt timestamp is present so all browsers auto-adopt this updated layout on next launch
    if (-not $jsonObj.updatedAt) {
        $jsonObj | Add-Member -NotePropertyName "updatedAt" -NotePropertyValue ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())
    }
    
    $jsonFormatted = $jsonObj | ConvertTo-Json -Depth 10
    Set-Content -Path $jsonPath -Value $jsonFormatted -Encoding UTF8

    $content = "// FBH Materialplaner - Standard Menue-Layout Konfiguration`nwindow.DEFAULT_TOOLBAR_LAYOUT = " + $jsonFormatted + ";"
    Set-Content -Path $targetJsPath -Value $content -Encoding UTF8
    exit 0
} else {
    Write-Error "Die Datei menu_layout.json wurde nicht gefunden!"
    exit 1
}
