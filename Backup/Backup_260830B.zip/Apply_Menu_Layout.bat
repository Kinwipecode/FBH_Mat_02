@echo off
cd /d "%~dp0"
start "" "%~dp0FBH_Layout_Sync_Manager.exe"
