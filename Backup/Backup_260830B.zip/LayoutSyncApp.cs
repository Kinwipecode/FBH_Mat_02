using System;
using System.IO;
using System.Windows.Forms;
using System.Drawing;
using System.Text.RegularExpressions;

namespace FbhLayoutSync
{
    public class MainForm : Form
    {
        private TextBox txtJsonPath;
        private TextBox txtJsPath;
        private Button btnBrowseJson;
        private Button btnBrowseJs;
        private Button btnSync;
        private CheckBox chkAutoClose;
        private TextBox txtLog;

        private string configPath;

        public MainForm()
        {
            string appDir = AppDomain.CurrentDomain.BaseDirectory;
            configPath = Path.Combine(appDir, "layout_sync_app_config.json");

            string defaultJson = Path.Combine(appDir, "menu_layout.json");
            string defaultJs = Path.Combine(appDir, "default_toolbar_layout.js");

            string lastJson = defaultJson;
            string lastJs = defaultJs;

            if (File.Exists(configPath))
            {
                try
                {
                    string cfgText = File.ReadAllText(configPath);
                    var mJson = Regex.Match(cfgText, "\"lastJsonPath\":\\s*\"([^\"]+)\"");
                    if (mJson.Success && File.Exists(mJson.Groups[1].Value.Replace("\\\\", "\\")))
                    {
                        lastJson = mJson.Groups[1].Value.Replace("\\\\", "\\");
                    }
                    var mJs = Regex.Match(cfgText, "\"lastJsPath\":\\s*\"([^\"]+)\"");
                    if (mJs.Success && File.Exists(mJs.Groups[1].Value.Replace("\\\\", "\\")))
                    {
                        lastJs = mJs.Groups[1].Value.Replace("\\\\", "\\");
                    }
                }
                catch { }
            }

            this.Text = "FBH Layout Sync Manager v3.0";
            this.Size = new Size(680, 480);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Color.FromArgb(15, 23, 42); // #0f172a
            this.ForeColor = Color.FromArgb(248, 250, 252);
            this.Font = new Font("Segoe UI", 9.5f);

            // Title Header
            Label lblTitle = new Label();
            lblTitle.Text = "⚡ FBH Layout Sync Manager v3.0";
            lblTitle.Font = new Font("Segoe UI", 16f, FontStyle.Bold);
            lblTitle.ForeColor = Color.FromArgb(56, 189, 248);
            lblTitle.Location = new Point(25, 20);
            lblTitle.AutoSize = true;
            this.Controls.Add(lblTitle);

            Label lblSub = new Label();
            lblSub.Text = "Synchronisiert Ihre menu_layout.json Datei mit dem App-Code (default_toolbar_layout.js)";
            lblSub.ForeColor = Color.FromArgb(148, 163, 184);
            lblSub.Location = new Point(25, 55);
            lblSub.AutoSize = true;
            this.Controls.Add(lblSub);

            // Label 1
            Label lblJson = new Label();
            lblJson.Text = "📄 Quell-Datei (menu_layout.json):";
            lblJson.Location = new Point(25, 95);
            lblJson.AutoSize = true;
            this.Controls.Add(lblJson);

            txtJsonPath = new TextBox();
            txtJsonPath.Location = new Point(25, 120);
            txtJsonPath.Size = new Size(480, 30);
            txtJsonPath.BackColor = Color.FromArgb(30, 41, 59);
            txtJsonPath.ForeColor = Color.White;
            txtJsonPath.Text = lastJson;
            this.Controls.Add(txtJsonPath);

            btnBrowseJson = new Button();
            btnBrowseJson.Text = "📂 Durchsuchen...";
            btnBrowseJson.Location = new Point(515, 118);
            btnBrowseJson.Size = new Size(125, 32);
            btnBrowseJson.FlatStyle = FlatStyle.Flat;
            btnBrowseJson.BackColor = Color.FromArgb(51, 65, 85);
            btnBrowseJson.ForeColor = Color.White;
            btnBrowseJson.Click += BtnBrowseJson_Click;
            this.Controls.Add(btnBrowseJson);

            // Label 2
            Label lblJs = new Label();
            lblJs.Text = "⚙️ Ziel-Code-Datei (default_toolbar_layout.js):";
            lblJs.Location = new Point(25, 165);
            lblJs.AutoSize = true;
            this.Controls.Add(lblJs);

            txtJsPath = new TextBox();
            txtJsPath.Location = new Point(25, 190);
            txtJsPath.Size = new Size(480, 30);
            txtJsPath.BackColor = Color.FromArgb(30, 41, 59);
            txtJsPath.ForeColor = Color.White;
            txtJsPath.Text = lastJs;
            this.Controls.Add(txtJsPath);

            btnBrowseJs = new Button();
            btnBrowseJs.Text = "📂 Durchsuchen...";
            btnBrowseJs.Location = new Point(515, 188);
            btnBrowseJs.Size = new Size(125, 32);
            btnBrowseJs.FlatStyle = FlatStyle.Flat;
            btnBrowseJs.BackColor = Color.FromArgb(51, 65, 85);
            btnBrowseJs.ForeColor = Color.White;
            btnBrowseJs.Click += BtnBrowseJs_Click;
            this.Controls.Add(btnBrowseJs);

            // Checkbox
            chkAutoClose = new CheckBox();
            chkAutoClose.Text = "Nach erfolgreicher Synchronisation automatisch schliessen";
            chkAutoClose.Location = new Point(25, 235);
            chkAutoClose.AutoSize = true;
            chkAutoClose.Checked = true;
            chkAutoClose.ForeColor = Color.FromArgb(203, 213, 225);
            this.Controls.Add(chkAutoClose);

            // Log Box
            txtLog = new TextBox();
            txtLog.Location = new Point(25, 270);
            txtLog.Size = new Size(615, 95);
            txtLog.Multiline = true;
            txtLog.ReadOnly = true;
            txtLog.ScrollBars = ScrollBars.Vertical;
            txtLog.BackColor = Color.FromArgb(30, 41, 59);
            txtLog.ForeColor = Color.FromArgb(163, 230, 53);
            txtLog.Font = new Font("Consolas", 9.5f);
            txtLog.Text = "Bereit. Waehlen Sie bei Bedarf eine abweichende menu_layout.json Datei.";
            this.Controls.Add(txtLog);

            // Action Button
            btnSync = new Button();
            btnSync.Text = "⚡ Layout jetzt synchronisieren & anwenden";
            btnSync.Location = new Point(25, 380);
            btnSync.Size = new Size(615, 42);
            btnSync.FlatStyle = FlatStyle.Flat;
            btnSync.BackColor = Color.FromArgb(16, 185, 129); // #10b981
            btnSync.ForeColor = Color.White;
            btnSync.Font = new Font("Segoe UI", 11f, FontStyle.Bold);
            btnSync.Click += BtnSync_Click;
            this.Controls.Add(btnSync);
        }

        private void BtnBrowseJson_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "JSON Layout-Dateien (*.json)|*.json|Alle Dateien (*.*)|*.*";
            dlg.Title = "menu_layout.json Quell-Datei auswaehlen";
            if (File.Exists(txtJsonPath.Text))
            {
                dlg.InitialDirectory = Path.GetDirectoryName(txtJsonPath.Text);
                dlg.FileName = Path.GetFileName(txtJsonPath.Text);
            }
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                txtJsonPath.Text = dlg.FileName;
                txtLog.Text = "Quell-Datei geaendert: " + dlg.FileName;
                txtLog.ForeColor = Color.FromArgb(56, 189, 248);
            }
        }

        private void BtnBrowseJs_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "JavaScript Dateien (*.js)|*.js|Alle Dateien (*.*)|*.*";
            dlg.Title = "default_toolbar_layout.js Ziel-Datei auswaehlen";
            if (File.Exists(txtJsPath.Text))
            {
                dlg.InitialDirectory = Path.GetDirectoryName(txtJsPath.Text);
                dlg.FileName = Path.GetFileName(txtJsPath.Text);
            }
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                txtJsPath.Text = dlg.FileName;
                txtLog.Text = "Ziel-Datei geaendert: " + dlg.FileName;
                txtLog.ForeColor = Color.FromArgb(56, 189, 248);
            }
        }

        private void BtnSync_Click(object sender, EventArgs e)
        {
            string jsonP = txtJsonPath.Text.Trim();
            string jsP = txtJsPath.Text.Trim();

            if (!File.Exists(jsonP))
            {
                txtLog.Text = "[FEHLER] Die Quell-Datei '" + jsonP + "' existiert nicht!";
                txtLog.ForeColor = Color.FromArgb(248, 113, 113);
                return;
            }

            try
            {
                string jsonText = File.ReadAllText(jsonP);

                // Add or update updatedAt timestamp
                long timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
                if (jsonText.Contains("\"updatedAt\""))
                {
                    jsonText = Regex.Replace(jsonText, "\"updatedAt\":\\s*\\d+", "\"updatedAt\": " + timestamp);
                }
                else
                {
                    jsonText = jsonText.TrimEnd();
                    if (jsonText.EndsWith("}"))
                    {
                        jsonText = jsonText.Substring(0, jsonText.Length - 1) + ",\n  \"updatedAt\": " + timestamp + "\n}";
                    }
                }

                File.WriteAllText(jsonP, jsonText);

                string jsContent = "// FBH Materialplaner - Standard Menue-Layout Konfiguration\nwindow.DEFAULT_TOOLBAR_LAYOUT = " + jsonText + ";";
                File.WriteAllText(jsP, jsContent);

                // Save config file for next launch
                string cleanJsonP = jsonP.Replace("\\", "\\\\");
                string cleanJsP = jsP.Replace("\\", "\\\\");
                string configContent = "{\n  \"lastJsonPath\": \"" + cleanJsonP + "\",\n  \"lastJsPath\": \"" + cleanJsP + "\"\n}";
                File.WriteAllText(configPath, configContent);

                txtLog.Text = "[ERFOLG] Layout wurde erfolgreich synchronisiert!\n\nQuelle: " + jsonP + "\nZiel: " + jsP + "\n\nDie Konfiguration wurde fuer den naechsten Start gespeichert.";
                txtLog.ForeColor = Color.FromArgb(74, 222, 128);

                if (chkAutoClose.Checked)
                {
                    Timer timer = new Timer();
                    timer.Interval = 1500;
                    timer.Tick += (s, args) => { timer.Stop(); this.Close(); };
                    timer.Start();
                }
            }
            catch (Exception ex)
            {
                txtLog.Text = "[FEHLER] " + ex.Message;
                txtLog.ForeColor = Color.FromArgb(248, 113, 113);
            }
        }

        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
